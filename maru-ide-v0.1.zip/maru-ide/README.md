# Maru IDE

Browser IDE foundation for a CodeSandbox-class self-hosted development environment.

## Current

- Monaco editor
- File explorer
- Multi-file in-memory project
- Local persistence with localStorage
- Browser preview for HTML/CSS/JS
- Terminal UI with basic local commands
- Responsive layout

## Next

- Backend API
- Real execution workers
- Project storage
- WebContainer integration
- Git integration
- Language runners
- Authentication and sharing
