import React, { useEffect, useMemo, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import Editor from '@monaco-editor/react'
import { Terminal } from '@xterm/xterm'
import { FitAddon } from '@xterm/addon-fit'
import '@xterm/xterm/css/xterm.css'
import './styles.css'

const DEFAULT_FILES = {
  'index.html': `<!doctype html>\n<html>\n  <head>\n    <meta charset="UTF-8" />\n    <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n    <title>Maru IDE</title>\n  </head>\n  <body>\n    <main class="app">\n      <h1>Hello, Maru IDE.</h1>\n      <p>Edit the files and press Run.</p>\n    </main>\n    <script src="app.js"></script>\n  </body>\n</html>`,
  'style.css': `body {\n  margin: 0;\n  min-height: 100vh;\n  font-family: system-ui, sans-serif;\n  background: #10131a;\n  color: #f3f5f7;\n}\n\n.app {\n  max-width: 760px;\n  margin: 0 auto;\n  padding: 64px 24px;\n}`,
  'app.js': `const title = document.querySelector('h1')\ntitle.addEventListener('click', () => {\n  title.textContent = 'It works.'\n})`,
  'main.py': `print("Hello from Python")`,
  'main.cpp': `#include <iostream>\n\nint main() {\n    std::cout << "Hello from C++\\n";\n    return 0;\n}`
}

const FILE_META = {
  'index.html': { language: 'html', icon: 'HTML' },
  'style.css': { language: 'css', icon: 'CSS' },
  'app.js': { language: 'javascript', icon: 'JS' },
  'main.py': { language: 'python', icon: 'PY' },
  'main.cpp': { language: 'cpp', icon: 'C++' }
}

function loadFiles() {
  try {
    const stored = localStorage.getItem('maru-ide-files')
    return stored ? { ...DEFAULT_FILES, ...JSON.parse(stored) } : DEFAULT_FILES
  } catch {
    return DEFAULT_FILES
  }
}

function buildPreview(files) {
  const html = files['index.html'] || ''
  const css = files['style.css'] || ''
  const js = files['app.js'] || ''
  const withCss = html.replace('</head>', `<style>${css}</style></head>`)
  return withCss.includes('</body>')
    ? withCss.replace('</body>', `<script>${js}\\n</script></body>`)
    : `${withCss}<script>${js}</script>`
}

function App() {
  const [files, setFiles] = useState(loadFiles)
  const [activeFile, setActiveFile] = useState('index.html')
  const [preview, setPreview] = useState('')
  const [bottomOpen, setBottomOpen] = useState(true)
  const terminalRef = useRef(null)
  const terminal = useRef(null)
  const fit = useRef(null)

  const currentLanguage = FILE_META[activeFile]?.language || 'plaintext'
  const currentValue = files[activeFile] ?? ''

  useEffect(() => {
    localStorage.setItem('maru-ide-files', JSON.stringify(files))
  }, [files])

  useEffect(() => {
    if (!terminalRef.current || terminal.current) return
    const instance = new Terminal({
      convertEol: true,
      cursorBlink: true,
      fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
      fontSize: 13,
      theme: {
        background: '#0a0c10',
        foreground: '#dce3ea',
        cursor: '#f4f6f8'
      }
    })
    const addon = new FitAddon()
    instance.loadAddon(addon)
    instance.open(terminalRef.current)
    addon.fit()
    instance.writeln('Maru IDE terminal')
    instance.writeln('Type commands here. The real execution backend comes next.')
    instance.write('$ ')
    let buffer = ''
    instance.onData(data => {
      if (data === '\r') {
        instance.write('\r\n')
        if (buffer === 'clear') {
          instance.clear()
        } else if (buffer === 'help') {
          instance.writeln('commands: help, clear, run, files')
        } else if (buffer === 'files') {
          Object.keys(files).forEach(name => instance.writeln(name))
        } else if (buffer === 'run') {
          setPreview(buildPreview(files))
          instance.writeln('Preview updated.')
        } else if (buffer) {
          instance.writeln(`${buffer}: command not found`)
        }
        buffer = ''
        instance.write('$ ')
      } else if (data === '\u007f') {
        if (buffer.length) {
          buffer = buffer.slice(0, -1)
          instance.write('\b \b')
        }
      } else if (data >= ' ') {
        buffer += data
        instance.write(data)
      }
    })
    terminal.current = instance
    fit.current = addon
    const resize = () => addon.fit()
    window.addEventListener('resize', resize)
    return () => window.removeEventListener('resize', resize)
  }, [files])

  const previewDoc = useMemo(() => preview || buildPreview(files), [files, preview])

  function updateFile(value) {
    setFiles(prev => ({ ...prev, [activeFile]: value ?? '' }))
  }

  function runProject() {
    setPreview(buildPreview(files))
    setBottomOpen(true)
    terminal.current?.writeln('')
    terminal.current?.writeln('Preview updated.')
    terminal.current?.write('$ ')
  }

  function resetProject() {
    setFiles(DEFAULT_FILES)
    setActiveFile('index.html')
    setPreview('')
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">MARU <span>IDE</span></div>
        <div className="project-name">Untitled Project</div>
        <div className="top-actions">
          <button onClick={resetProject}>Reset</button>
          <button className="run" onClick={runProject}>Run</button>
        </div>
      </header>

      <main className="workspace">
        <aside className="sidebar">
          <div className="sidebar-title">EXPLORER</div>
          <div className="folder">⌄ project</div>
          {Object.keys(files).map(name => (
            <button
              key={name}
              className={`file-row ${activeFile === name ? 'active' : ''}`}
              onClick={() => setActiveFile(name)}
            >
              <span className="file-icon">{FILE_META[name]?.icon || 'TXT'}</span>
              <span>{name}</span>
            </button>
          ))}
        </aside>

        <section className="editor-area">
          <div className="tabs">
            <div className="tab active">
              <span className="file-icon">{FILE_META[activeFile]?.icon || 'TXT'}</span>
              {activeFile}
            </div>
          </div>
          <div className="editor-pane">
            <Editor
              height="100%"
              language={currentLanguage}
              value={currentValue}
              onChange={updateFile}
              theme="vs-dark"
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                padding: { top: 14, bottom: 14 },
                scrollBeyondLastLine: false,
                automaticLayout: true,
                smoothScrolling: true
              }}
            />
          </div>

          <div className={`bottom-panel ${bottomOpen ? 'open' : ''}`}>
            <div className="panel-tabs">
              <button className="panel-tab active">TERMINAL</button>
              <button className="panel-tab">OUTPUT</button>
              <button className="panel-tab">PROBLEMS</button>
              <button className="panel-toggle" onClick={() => setBottomOpen(value => !value)}>{bottomOpen ? '⌄' : '⌃'}</button>
            </div>
            <div className="terminal" ref={terminalRef} />
          </div>
        </section>

        <section className="preview-area">
          <div className="preview-header">
            <span>PREVIEW</span>
            <button onClick={runProject}>Refresh</button>
          </div>
          <iframe title="preview" srcDoc={previewDoc} sandbox="allow-scripts" />
        </section>
      </main>
    </div>
  )
}

createRoot(document.getElementById('root')).render(<App />)
